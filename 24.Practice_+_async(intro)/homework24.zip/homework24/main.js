let form = document.querySelector('form')

let button = document.querySelector('.btn');

button.addEventListener('click', function(event){
    event.preventDefault();

    const payload = serializeForm(form)

    sendAjax( {
        method: 'POST',
        url: 'http://localhost:3000/foo',
        succs: response => {
            if(response !== "Not found"){
                let urlToJson = `goods/${response}.json`;
                sendAjax({
                    method: 'GET',
                    url: `http://localhost:3000/${urlToJson}`,
                    succs: response => {
                        const data = JSON.parse(response);
                        render(data)
                        
                    }
                })
            } else {
                alert(response)
            }
        },
        body: payload
    }
    )
})

function render(info) {
    form.classList.add("hide");
    const userGoods = info;
    
    const divContainer = document.createElement("div");
    divContainer.classList.add('container');
    
    userGoods.forEach(item => {
        const {model, price, img} = item;

        const content = `<div class="goods">
        <div class="title"><img src="${img}">
        </div>
        <div class="model">${model}</div>
        <div class="price">${price} грн.</div>
    </div>`
        
        divContainer.insertAdjacentHTML("beforeend", content);

    })
    document.body.append(divContainer)
}
