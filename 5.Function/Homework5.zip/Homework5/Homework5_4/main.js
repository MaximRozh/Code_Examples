// Создать функцию, которая убирает из строки все символы, которые мы передали вторым аргументом.
// 'func("hello world", ['l', 'd'])' вернет нам "heo wor"

function cutElem (fraction, cut) {
    
    for(var i = 0; i < cut.length; i++) {
        fraction = fraction.split(cut[i]).join("");
    }

    return fraction;
  }
  
  console.log(cutElem("Hello world", ["l", "d"]));
